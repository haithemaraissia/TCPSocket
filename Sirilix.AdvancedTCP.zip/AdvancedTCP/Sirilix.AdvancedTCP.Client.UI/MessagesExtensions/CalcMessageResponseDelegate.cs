﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sirilix.AdvancedTCP.Client.UI.MessagesExtensions
{
    public delegate void CalcMessageResponseDelegate(Client senderClient, CalcMessageResponse response);
}
